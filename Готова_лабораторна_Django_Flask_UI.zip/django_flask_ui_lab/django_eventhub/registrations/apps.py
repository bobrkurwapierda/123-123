"""Application configuration for registrations."""
from django.apps import AppConfig


class RegistrationsConfig(AppConfig):
    """Django app with event pages and registration form."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "registrations"
