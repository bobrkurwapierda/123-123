"""Django forms for the EventHub registration workflow."""
from django import forms


EVENT_CHOICES = [
    ("python", "Python-практикум"),
    ("web", "Web UI workshop"),
    ("career", "Кар'єрна консультація"),
]


class EventRegistrationForm(forms.Form):
    """Form for event registration with server-side validation."""

    full_name = forms.CharField(
        label="ПІБ",
        min_length=3,
        max_length=60,
        widget=forms.TextInput(attrs={"placeholder": "Наприклад: Іван Петренко"}),
    )
    email = forms.EmailField(
        label="Електронна пошта",
        widget=forms.EmailInput(attrs={"placeholder": "name@example.com"}),
    )
    event_type = forms.ChoiceField(
        label="Подія",
        choices=EVENT_CHOICES,
    )
    message = forms.CharField(
        label="Коментар",
        min_length=15,
        widget=forms.Textarea(attrs={"rows": 4, "placeholder": "Опишіть, чому хочете взяти участь"}),
    )

    def clean_full_name(self) -> str:
        """Reject names that contain digits."""
        value = self.cleaned_data["full_name"].strip()
        if any(char.isdigit() for char in value):
            raise forms.ValidationError("ПІБ не повинно містити цифр.")
        return value

    def clean_message(self) -> str:
        """Require at least three words in the comment field."""
        value = self.cleaned_data["message"].strip()
        if len(value.split()) < 3:
            raise forms.ValidationError("Коментар має містити щонайменше три слова.")
        return value
