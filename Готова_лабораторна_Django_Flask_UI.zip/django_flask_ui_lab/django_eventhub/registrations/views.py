"""Django views for EventHub pages and registration form."""
from datetime import date
from django.contrib import messages
from django.shortcuts import redirect, render

from .forms import EventRegistrationForm

EVENTS = [
    {"title": "Python-практикум", "places": 18, "level": "basic"},
    {"title": "Web UI workshop", "places": 12, "level": "middle"},
    {"title": "Кар'єрна консультація", "places": 8, "level": "intro"},
]


def home(request):
    """Render the home page with simple context values."""
    context = {
        "page_title": "EventHub Ukraine",
        "active_events_count": len(EVENTS),
        "events": EVENTS,
        "current_year": date.today().year,
    }
    return render(request, "registrations/home.html", context)


def events(request):
    """Render the events list page."""
    context = {
        "page_title": "Доступні події",
        "events": EVENTS,
        "current_year": date.today().year,
    }
    return render(request, "registrations/events.html", context)


def register(request):
    """Handle GET and POST requests for the registration form."""
    if request.method == "POST":
        form = EventRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, "Реєстрацію успішно надіслано.")
            return redirect("registrations:register")
    else:
        form = EventRegistrationForm()

    return render(
        request,
        "registrations/register.html",
        {"form": form, "page_title": "Реєстрація", "current_year": date.today().year},
    )
