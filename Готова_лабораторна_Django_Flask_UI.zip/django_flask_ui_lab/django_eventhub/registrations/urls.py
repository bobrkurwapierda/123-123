"""URL routes for registration pages."""
from django.urls import path
from . import views

app_name = "registrations"

urlpatterns = [
    path("", views.home, name="home"),
    path("events/", views.events, name="events"),
    path("register/", views.register, name="register"),
]
