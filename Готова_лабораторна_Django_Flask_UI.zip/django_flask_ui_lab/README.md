# Лабораторна робота: UI у Django та Flask

Предметна область: реєстрація користувачів на навчальні події.
У репозиторії є два веб-додатки з аналогічною логікою:

- `django_eventhub/` — реалізація на Django;
- `flask_eventhub/` — реалізація на Flask + Flask-WTF.

## 1. Встановлення

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## 2. Запуск Django-проєкту

```bash
cd django_eventhub
python manage.py migrate
python manage.py runserver
```

Сторінки:

- http://127.0.0.1:8000/
- http://127.0.0.1:8000/events/
- http://127.0.0.1:8000/register/

## 3. Запуск Flask-проєкту

В іншому терміналі або після завершення Django-сервера:

```bash
cd flask_eventhub
python app.py
```

Сторінки:

- http://127.0.0.1:5000/
- http://127.0.0.1:5000/events
- http://127.0.0.1:5000/register

## 4. Що реалізовано

- маршрути для кількох URL в обох фреймворках;
- базові та похідні шаблони з успадкуванням;
- передача контексту: рядок, число, список/словник;
- DTL-фільтри в Django та Jinja2-макрос у Flask;
- форми з чотирма полями;
- серверна валідація, кастомні правила;
- CSRF-захист;
- flash-повідомлення;
- порівняння підходів Django та Flask у звіті.

## 5. Примітка щодо секретів

У коді використано навчальні значення `SECRET_KEY` тільки для локального запуску.
Для реального проєкту ключ потрібно передавати через змінну середовища.
