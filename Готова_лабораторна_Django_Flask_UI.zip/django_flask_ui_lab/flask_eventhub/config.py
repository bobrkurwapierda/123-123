"""Configuration for the Flask EventHub application."""
import os


class Config:
    """Base Flask configuration."""

    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "dev-only-flask-key-for-local-lab")
    WTF_CSRF_ENABLED = True
