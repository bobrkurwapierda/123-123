"""Flask-WTF forms for event registration."""
from flask_wtf import FlaskForm
from wtforms import EmailField, SelectField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email, Length, ValidationError


class EventRegistrationForm(FlaskForm):
    """Registration form with declarative and custom validation."""

    full_name = StringField(
        "ПІБ",
        validators=[
            DataRequired(message="Вкажіть ПІБ."),
            Length(min=3, max=60, message="ПІБ має містити від 3 до 60 символів."),
        ],
        render_kw={"placeholder": "Наприклад: Іван Петренко"},
    )
    email = EmailField(
        "Електронна пошта",
        validators=[DataRequired(message="Вкажіть email."), Email(message="Некоректний формат email.")],
        render_kw={"placeholder": "name@example.com"},
    )
    event_type = SelectField(
        "Подія",
        choices=[
            ("python", "Python-практикум"),
            ("web", "Web UI workshop"),
            ("career", "Кар'єрна консультація"),
        ],
        validators=[DataRequired(message="Оберіть подію.")],
    )
    message = TextAreaField(
        "Коментар",
        validators=[
            DataRequired(message="Додайте коментар."),
            Length(min=15, message="Коментар має містити щонайменше 15 символів."),
        ],
        render_kw={"rows": 4, "placeholder": "Опишіть, чому хочете взяти участь"},
    )
    submit = SubmitField("Надіслати")

    def validate_full_name(self, field: StringField) -> None:
        """Reject names that contain digits."""
        if any(char.isdigit() for char in field.data):
            raise ValidationError("ПІБ не повинно містити цифр.")

    def validate_message(self, field: TextAreaField) -> None:
        """Require at least three words in the comment."""
        if len(field.data.split()) < 3:
            raise ValidationError("Коментар має містити щонайменше три слова.")
