"""Flask EventHub application with templates, forms and CSRF protection."""
from datetime import date

from flask import Flask, flash, redirect, render_template, url_for

from config import Config
from forms import EventRegistrationForm

app = Flask(__name__)
app.config.from_object(Config)

EVENTS = [
    {"title": "Python-практикум", "places": 18, "level": "basic"},
    {"title": "Web UI workshop", "places": 12, "level": "middle"},
    {"title": "Кар'єрна консультація", "places": 8, "level": "intro"},
]


@app.route("/")
def home():
    """Render the Flask home page."""
    return render_template(
        "home.html",
        page_title="EventHub Ukraine",
        active_events_count=len(EVENTS),
        events=EVENTS,
        current_year=date.today().year,
    )


@app.route("/events")
def events():
    """Render a list of available events."""
    return render_template(
        "events.html",
        page_title="Доступні події",
        events=EVENTS,
        current_year=date.today().year,
    )


@app.route("/register", methods=["GET", "POST"])
def register():
    """Handle GET and POST requests for the Flask-WTF registration form."""
    form = EventRegistrationForm()
    if form.validate_on_submit():
        flash("Реєстрацію успішно надіслано.", "success")
        return redirect(url_for("register"))
    return render_template("register.html", form=form, page_title="Реєстрація", current_year=date.today().year)


if __name__ == "__main__":
    app.run(debug=True)
